package Project3ish;

import com.google.gson.Gson;
import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class TweetLoader {

    // class variables
    private Twitter twitter;


    public TweetLoader() {
        configureKeys();
    }

    /***
     * Sets your authentication keys
     */
    private void configureKeys(){
        ConfigurationBuilder cb = new ConfigurationBuilder();

// This continuous set of function calls all connected together is referred to
// as "method chaining". It is a popular technique amongst web developers and has
// gradually found its way into other languages.
//
// The way it works is that each setter returns a reference to the object.
// For example, the code in the setDebugEnabled function might look like this:
//
//  ConfigurationBuilder setDebugEnabled(Boolean value) {
//      this.debugEnabled = value;
//
//      // Returning "this" allows method chaining.
//      return this;
//  }
//
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey("YFNuWu3xs9EnJ8b7zbLBJ8GWJ")
                .setOAuthConsumerSecret("XBguln2e3ujqC12mLz0fs652QaoySkJcdeeJJ2Vf1VZuqQbRKL")
                .setOAuthAccessToken("913077252497084416-K64E8Zn2d7DBi6gCQ1UsKn8go1Ib4rn")
                .setOAuthAccessTokenSecret("csd85la2oB0pGlYmHwNbdnpOJchN6CGpMObnlMwplChU8")
                .setJSONStoreEnabled(true);

        TwitterFactory tf = new TwitterFactory(cb.build());
        this.twitter = tf.getInstance();
    }

    /***
     *
     * @param hashtag
     * @return
     * @throws TwitterException
     * converts a
     */
    public Map<String, BYUITweet> retrieveTweetsWithHashTag(String hashtag) throws TwitterException {

        //create an instance of a map
        Map map = new TreeMap();

        // creates a query that passes in a string
        Query hasher = new Query(hashtag);

        // make a twitter search that tells us our hash results
        QueryResult result = twitter.search(hasher);


        // from http://twitter4j.org/en/code-examples.html

        // convert our json to our BYUITweet
        // for loop to put our tweet results into a map
        for (Status status : result.getTweets()) {
            String json = TwitterObjectFactory.getRawJSON(status);


            // deserialize the Query with a GSon
            Gson gson = new Gson();
            BYUITweet tweeter = gson.fromJson(json, BYUITweet.class);


            // put the values in the map
            map.put(status.getUser().getScreenName(), tweeter);

        }
            return map;
    }
}
