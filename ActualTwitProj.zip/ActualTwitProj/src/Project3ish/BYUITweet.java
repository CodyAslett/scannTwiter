package Project3ish;

public class BYUITweet {


    User user;

    String text;



    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }



    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
